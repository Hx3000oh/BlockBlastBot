package com.blastbot

import android.content.Context
import android.content.SharedPreferences
import java.io.File

/** Everything that must survive restarts: screen geometry, learned skin colours, timings, tuned drag offsets. */
class Profile {
    var boardLeft = 0f
    var boardTop = 0f
    var cell = 0f                 // board cell size in px
    var trayLeft = 0f
    var trayTop = 0f
    var trayRight = 0f
    var trayBottom = 0f
    var trayScale = 0f            // tray cell size / board cell size (0 = auto-detect)
    var offX = 0f                 // finger offset from target centre, in board cells (auto-tuned)
    var offY = 0f
    var tuned = false
    var dragMs = 110
    var gapMs = 80
    var clearWaitMs = 420
    var threshold = 70            // colour distance (sum of |dR|+|dG|+|dB|) for "cell is filled"
    var pieceTol = 70             // colour distance from tray background for "pixel belongs to a piece"
    var learned = false
    val ref = IntArray(64)        // per-cell "empty" colour, learned from the current skin

    val geometryReady: Boolean get() = cell > 0f && trayRight > trayLeft && trayBottom > trayTop

    fun save(ctx: Context) {
        val e = ctx.getSharedPreferences("profile", Context.MODE_PRIVATE).edit()
        e.putFloat("boardLeft", boardLeft).putFloat("boardTop", boardTop).putFloat("cell", cell)
        e.putFloat("trayLeft", trayLeft).putFloat("trayTop", trayTop)
        e.putFloat("trayRight", trayRight).putFloat("trayBottom", trayBottom)
        e.putFloat("trayScale", trayScale).putFloat("offX", offX).putFloat("offY", offY)
        e.putBoolean("tuned", tuned).putBoolean("learned", learned)
        e.putInt("dragMs", dragMs).putInt("gapMs", gapMs).putInt("clearWaitMs", clearWaitMs)
        e.putInt("threshold", threshold).putInt("pieceTol", pieceTol)
        e.putString("ref", ref.joinToString(","))
        e.apply()
    }

    companion object {
        fun load(ctx: Context): Profile {
            val p = Profile()
            val s = ctx.getSharedPreferences("profile", Context.MODE_PRIVATE)
            p.boardLeft = s.getFloat("boardLeft", 0f); p.boardTop = s.getFloat("boardTop", 0f)
            p.cell = s.getFloat("cell", 0f)
            p.trayLeft = s.getFloat("trayLeft", 0f); p.trayTop = s.getFloat("trayTop", 0f)
            p.trayRight = s.getFloat("trayRight", 0f); p.trayBottom = s.getFloat("trayBottom", 0f)
            p.trayScale = s.getFloat("trayScale", 0f)
            p.offX = s.getFloat("offX", 0f); p.offY = s.getFloat("offY", 0f)
            p.tuned = s.getBoolean("tuned", false); p.learned = s.getBoolean("learned", false)
            p.dragMs = s.getInt("dragMs", 110); p.gapMs = s.getInt("gapMs", 80)
            p.clearWaitMs = s.getInt("clearWaitMs", 420)
            p.threshold = s.getInt("threshold", 70); p.pieceTol = s.getInt("pieceTol", 70)
            val refs = s.getString("ref", null)?.split(",")
            if (refs != null && refs.size == 64) for (i in 0 until 64) p.ref[i] = refs[i].toIntOrNull() ?: 0
            return p
        }
    }
}

/** Lifetime counters: moves, lines, best multi-line clear and best consecutive-clear streak ("combos"). */
object Stats {
    var moves = 0L
    var lines = 0L
    var bestLines = 0
    var bestStreak = 0
    private var streak = 0
    private var dirty = 0
    private var prefs: SharedPreferences? = null

    fun load(ctx: Context) {
        val s = ctx.getSharedPreferences("stats", Context.MODE_PRIVATE)
        prefs = s
        moves = s.getLong("moves", 0); lines = s.getLong("lines", 0)
        bestLines = s.getInt("bestLines", 0); bestStreak = s.getInt("bestStreak", 0)
    }

    fun record(cleared: Int) {
        moves++
        lines += cleared
        if (cleared > 0) {
            streak++
            if (cleared > bestLines) bestLines = cleared
            if (streak > bestStreak) bestStreak = streak
        } else streak = 0
        if (++dirty >= 15) save()
    }

    fun save() {
        dirty = 0
        prefs?.edit()?.putLong("moves", moves)?.putLong("lines", lines)
            ?.putInt("bestLines", bestLines)?.putInt("bestStreak", bestStreak)?.apply()
    }

    fun summary() = "Moves: $moves   Lines cleared: $lines\nBest single clear: $bestLines lines   Best combo streak: $bestStreak"
}

/** Remembers solved (board, pieces) situations on disk. Boards rarely repeat, so this mostly helps the opening. */
class PlanCache(private val file: File, private val max: Int = 4000) {
    private val map = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > max
    }

    private fun key(board: Long, masks: List<Long>) = "$board:" + masks.joinToString(":")

    fun get(board: Long, masks: List<Long>): Plan? {
        val v = map[key(board, masks)] ?: return null
        return try {
            val parts = v.split("|")
            val moves = parts[0].split(";").filter { it.isNotEmpty() }.map {
                val a = it.split(",")
                Move(a[0].toInt(), a[1].toInt(), a[2].toInt(), a[3].toInt())
            }
            Plan(moves, parts[1].toLong(), 0.0)
        } catch (e: Exception) {
            null
        }
    }

    fun put(board: Long, masks: List<Long>, plan: Plan) {
        map[key(board, masks)] = plan.moves.joinToString(";") { "${it.piece},${it.row},${it.col},${it.cleared}" } + "|" + plan.finalBoard
    }

    fun load() {
        try {
            if (!file.exists()) return
            file.forEachLine { line ->
                val i = line.indexOf('=')
                if (i > 0) map[line.substring(0, i)] = line.substring(i + 1)
            }
        } catch (e: Exception) {
        }
    }

    fun save() {
        try {
            file.bufferedWriter().use { w -> for ((k, v) in map) { w.write("$k=$v"); w.newLine() } }
        } catch (e: Exception) {
        }
    }

    val size: Int get() = map.size
}

enum class Cmd { LEARN, TEST }

/** Tiny shared state between the activity and the two services. */
object Bot {
    lateinit var profile: Profile
    @Volatile var running = false
    @Volatile var pending: Cmd? = null
    @Volatile var statusListener: ((String) -> Unit)? = null
    @Volatile var debugListener: ((String) -> Unit)? = null
    private var ready = false

    fun ensure(ctx: Context) {
        if (ready) return
        profile = Profile.load(ctx)
        Stats.load(ctx)
        ready = true
    }

    fun reset(ctx: Context) {
        profile = Profile()
        profile.save(ctx)
    }

    fun status(s: String) { statusListener?.invoke(s) }
    fun debug(s: String) { debugListener?.invoke(s) }
}
