package com.blastbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statsTv: TextView
    private lateinit var dragEt: EditText
    private lateinit var gapEt: EditText
    private lateinit var clearEt: EditText
    private lateinit var thrEt: EditText
    private lateinit var pieceEt: EditText
    private val REQ_CAPTURE = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Bot.ensure(applicationContext)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        fun label(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size; setPadding(0, pad / 2, 0, 0) }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }
        fun number(hint: String, v: Int) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(v.toString()); this.hint = hint
        }

        root.addView(label("Block Blast Bot", 22f))
        root.addView(label(
            "Setup (once):\n" +
                "1. Enable the accessibility service (needed to perform drags).\n" +
                "2. Start screen capture (Android asks for permission each time).\n" +
                "3. Open Block Blast. Use the floating panel: 1 Calibrate (4 taps) -> new game -> 2 Learn skin -> Test read -> Start.\n" +
                "Everything runs on this phone. The app has no internet permission."
        ))
        root.addView(button("1. Open accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(button("2. Start screen capture") {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        })
        root.addView(button("Stop capture / bot") {
            Bot.running = false
            stopService(Intent(this, CaptureService::class.java))
        })

        root.addView(label("Timing (ms)"))
        dragEt = number("Drag duration", Bot.profile.dragMs)
        gapEt = number("Pause between moves", Bot.profile.gapMs)
        clearEt = number("Wait after a line clear", Bot.profile.clearWaitMs)
        thrEt = number("Board colour threshold", Bot.profile.threshold)
        pieceEt = number("Tray piece threshold", Bot.profile.pieceTol)
        for ((t, e) in listOf(
            "Drag duration (lower = faster; below ~60 may stop registering)" to dragEt,
            "Pause between moves" to gapEt,
            "Wait after a line clear (animation)" to clearEt,
            "Board colour threshold (raise if empty cells read as filled)" to thrEt,
            "Tray piece threshold (raise if the background reads as pieces)" to pieceEt
        )) { root.addView(label(t, 12f)); root.addView(e) }
        root.addView(button("Save settings") {
            val p = Bot.profile
            p.dragMs = dragEt.text.toString().toIntOrNull()?.coerceIn(30, 600) ?: p.dragMs
            p.gapMs = gapEt.text.toString().toIntOrNull()?.coerceIn(0, 2000) ?: p.gapMs
            p.clearWaitMs = clearEt.text.toString().toIntOrNull()?.coerceIn(0, 3000) ?: p.clearWaitMs
            p.threshold = thrEt.text.toString().toIntOrNull()?.coerceIn(20, 300) ?: p.threshold
            p.pieceTol = pieceEt.text.toString().toIntOrNull()?.coerceIn(20, 300) ?: p.pieceTol
            p.save(applicationContext)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Reset calibration + learned skin") {
            Bot.reset(applicationContext)
            Toast.makeText(this, "Reset - calibrate again", Toast.LENGTH_SHORT).show()
        })

        statsTv = label("", 13f)
        root.addView(label("Stats / combos"))
        root.addView(statsTv)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        statsTv.text = Stats.summary()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
            )
            Toast.makeText(this, "Capture started - open Block Blast", Toast.LENGTH_LONG).show()
        }
    }
}
