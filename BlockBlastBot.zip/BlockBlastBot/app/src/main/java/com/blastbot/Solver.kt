package com.blastbot

class Move(val piece: Int, val row: Int, val col: Int, val cleared: Int)

class Plan(val moves: List<Move>, val finalBoard: Long, val score: Double)

/**
 * Plans the three visible pieces together: tries every order (up to 6), and for each order
 * runs a beam search over all placements. Lines are cleared after every placement, so an early
 * piece can open room for a later one. Not thread-safe (use from a single coroutine).
 *
 * Weights were tuned in a C port of this exact code against a random-piece simulator (see tools/sim.c).
 */
class Solver(private val beamWidth: Int = 16) {

    private class Node(
        val board: Long,
        val parent: Node?,
        val piece: Int,
        val row: Int,
        val col: Int,
        val cleared: Int,
        val streak: Int,
        val gain: Double,
        val score: Double,
        val depth: Int
    )

    private companion object {
        const val W_FILLED = 2.0
        const val W_TRANS = 0.8
        const val W_R1 = 14.0
        const val W_R2 = 7.0
        const val W_R3 = 2.0
        const val W_FLEX = 0.6
        const val W_DEAD = 3.0
        const val W_COMBO = 6.0
        val LINE_BONUS = doubleArrayOf(0.0, 10.0, 30.0, 60.0, 100.0, 150.0, 210.0, 280.0, 360.0, 450.0)
    }

    /** @param pieces shape masks anchored at (0,0), one per tray slot; 0L = empty slot. */
    fun solve(board: Long, pieces: List<Long>): Plan? {
        val idx = pieces.indices.filter { pieces[it] != 0L }
        if (idx.isEmpty()) return null
        var best: Node? = null
        val seen = HashSet<List<Long>>()
        for (order in permutations(idx)) {
            if (!seen.add(order.map { pieces[it] })) continue
            val cand = beam(board, order, pieces) ?: continue
            if (best == null || better(cand, best)) best = cand
        }
        val b = best ?: return null
        if (b.depth == 0) return null
        val moves = ArrayList<Move>()
        var n: Node? = b
        while (n != null && n.parent != null) {
            moves.add(Move(n.piece, n.row, n.col, n.cleared))
            n = n.parent
        }
        moves.reverse()
        return Plan(moves, b.board, b.score)
    }

    private fun better(a: Node, b: Node) = a.depth > b.depth || (a.depth == b.depth && a.score > b.score)

    private fun beam(board: Long, order: List<Int>, pieces: List<Long>): Node? {
        var cur: List<Node> = listOf(Node(board, null, -1, 0, 0, 0, 0, 0.0, 0.0, 0))
        var best: Node? = null
        for (d in order.indices) {
            val shape = Shape.of(pieces[order[d]])
            val next = ArrayList<Node>()
            for (nd in cur) {
                var any = false
                for (k in shape.placements.indices) {
                    val pm = shape.placements[k]
                    if ((nd.board and pm) != 0L) continue
                    any = true
                    var nb = nd.board or pm
                    var clear = 0L
                    var lines = 0
                    for (i in 0 until 8) {
                        if ((nb and Bits.ROW[i]) == Bits.ROW[i]) { clear = clear or Bits.ROW[i]; lines++ }
                        if ((nb and Bits.COL[i]) == Bits.COL[i]) { clear = clear or Bits.COL[i]; lines++ }
                    }
                    nb = nb and clear.inv()
                    var gain = nd.gain
                    var streak = 0
                    if (lines > 0) {
                        gain += LINE_BONUS[minOf(lines, 9)] + W_COMBO * nd.streak
                        streak = nd.streak + 1
                    }
                    next.add(
                        Node(nb, nd, order[d], k / shape.cols, k % shape.cols, lines, streak, gain,
                            gain + evalBoard(nb), d + 1)
                    )
                }
                if (!any && nd.depth > 0) {
                    if (best == null || better(nd, best)) best = nd
                }
            }
            if (next.isEmpty()) return best
            next.sortByDescending { it.score }
            cur = if (next.size > beamWidth) next.subList(0, beamWidth) else next
        }
        for (nd in cur) if (best == null || better(nd, best)) best = nd
        return best
    }

    private fun evalBoard(b: Long): Double {
        var s = -W_FILLED * b.countOneBits()

        // perimeter / fragmentation
        val hx = (b xor (b ushr 1)) and Bits.NOT7
        val vx = (b xor (b ushr 8)) and Bits.LOW56
        s -= W_TRANS * (hx.countOneBits() + vx.countOneBits())

        // tiny empty pockets are nearly always dead space
        var empty = b.inv()
        while (empty != 0L) {
            var comp = empty and (-empty)
            while (true) {
                val g = (comp or Bits.east(comp) or Bits.west(comp) or (comp shl 8) or (comp ushr 8)) and empty
                if (g == comp) break
                comp = g
            }
            when (comp.countOneBits()) {
                1 -> s -= W_R1
                2 -> s -= W_R2
                3 -> s -= W_R3
            }
            empty = empty and comp.inv()
        }

        // shapes that could no longer be placed anywhere = imminent game over
        for (sh in ShapeLib.all) {
            var ok = false
            for (pm in sh.placements) if ((b and pm) == 0L) { ok = true; break }
            if (!ok) s -= W_DEAD * sh.cells
        }

        // keep room for the awkward big pieces
        for (sh in ShapeLib.probes) {
            var cnt = 0
            for (pm in sh.placements) {
                if ((b and pm) == 0L) { cnt++; if (cnt >= 6) break }
            }
            s += W_FLEX * cnt
        }
        return s
    }

    private fun permutations(items: List<Int>): List<List<Int>> {
        if (items.size <= 1) return listOf(items)
        val out = ArrayList<List<Int>>()
        for (i in items.indices) {
            val rest = items.filterIndexed { j, _ -> j != i }
            for (p in permutations(rest)) out.add(listOf(items[i]) + p)
        }
        return out
    }
}
