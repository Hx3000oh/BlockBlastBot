package com.blastbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random

/**
 * Loop: read screen -> read board + tray -> solve all pieces at once -> drag them -> verify -> repeat.
 * 100% on-device: no network permission is even declared in the manifest.
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "blastbot"
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var screenW = 0
    private var screenH = 0
    private var frame: Frame? = null
    private var buf: ByteArray? = null
    private val solver = Solver()
    private lateinit var cache: PlanCache

    private var idle = 0
    private var mismatches = 0
    private var goodStreak = 0
    private var failedDrops = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Bot.ensure(applicationContext)
        startAsForeground()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))

        val b = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()
        val ir = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = ir
        display = mp.createVirtualDisplay(
            "blastbot", screenW, screenH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.surface, null, null
        )

        cache = PlanCache(File(filesDir, "plans_v1.txt")).also { it.load() }
        Bot.status("Capture ready. Open Block Blast.")
        scope.launch { loop() }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Block Blast Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Block Blast Bot")
            .setContentText("Screen capture active (on-device only)")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        Bot.running = false
        Bot.status("Capture stopped")
        scope.cancel()
        try { cache.save() } catch (e: Exception) { }
        Stats.save()
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- capture

    /** Latest screen contents. Static screens deliver no new images, so the last copy is reused. */
    private suspend fun grab(timeoutMs: Long = 700): Frame? {
        val t0 = SystemClock.uptimeMillis()
        while (true) {
            val img = reader?.acquireLatestImage()
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val bb = pl.buffer
                    val n = bb.limit()
                    var arr = buf
                    if (arr == null || arr.size != n) { arr = ByteArray(n); buf = arr; frame = null }
                    bb.position(0)
                    bb.get(arr, 0, n)
                    if (frame == null) frame = Frame(screenW, screenH, pl.rowStride, pl.pixelStride, arr)
                } finally {
                    img.close()
                }
                return frame
            }
            if (frame != null) return frame
            if (SystemClock.uptimeMillis() - t0 > timeoutMs) return null
            delay(15)
        }
    }

    private suspend fun readStable(withTray: Boolean): Snapshot? {
        val p = Bot.profile
        var prev: Snapshot? = null
        repeat(14) {
            val f = grab() ?: return null
            val snap = Snapshot(Reader.readBoard(f, p), if (withTray) Reader.readTray(f, p) else emptyList())
            val pr = prev
            if (pr != null && pr.sameAs(snap)) return snap
            prev = snap
            delay(60)
        }
        return null
    }

    // ---------------------------------------------------------------- main loop

    private suspend fun loop() {
        while (scope.isActive) {
            try {
                handlePending()
                if (!Bot.running) { delay(120); continue }
                step()
            } catch (e: Exception) {
                Bot.status("Error: ${e.message}")
                delay(500)
            }
        }
    }

    private suspend fun handlePending() {
        val cmd = Bot.pending ?: return
        Bot.pending = null
        val p = Bot.profile
        if (!p.geometryReady) { Bot.status("Press 1 Calibrate first"); return }
        val f = grab() ?: run { Bot.status("No frame yet - is capture running?"); return }
        when (cmd) {
            Cmd.LEARN -> {
                if (Reader.learn(f, p)) {
                    p.save(applicationContext)
                    Bot.status("Skin learned")
                } else {
                    Bot.status("Board too full to learn - start a new game")
                }
            }
            Cmd.TEST -> {
                if (!p.learned) { Bot.status("Press 2 Learn skin first"); return }
                val board = Reader.readBoard(f, p)
                val tray = Reader.readTray(f, p)
                val sb = StringBuilder(Bits.render(board)).append("\n")
                tray.forEachIndexed { i, tp ->
                    val m = tp?.mask ?: 0L
                    sb.append("P${i + 1}: ")
                    if (m == 0L) sb.append("-") else { val s = Shape.of(m); sb.append("${s.w}x${s.h} (${s.cells})") }
                    sb.append("\n")
                }
                p.save(applicationContext)
                Bot.debug(sb.toString().trimEnd())
                Bot.status("Test read done")
            }
        }
    }

    private fun stopWith(msg: String) {
        Bot.running = false
        Bot.status(msg)
        try { cache.save() } catch (e: Exception) { }
        Stats.save()
    }

    private suspend fun step() {
        val p = Bot.profile
        if (!p.geometryReady) { stopWith("Press 1 Calibrate first"); return }
        if (!p.learned) { stopWith("Press 2 Learn skin first"); return }
        val svc = BotAccessibilityService.instance ?: run { stopWith("Enable the accessibility service"); return }

        val snap = readStable(true) ?: run { Bot.status("Waiting for a stable screen..."); delay(150); return }
        val slots = snap.pieces
        val masks = slots.map { it?.mask ?: 0L }
        if (masks.all { it == 0L }) {
            if (++idle > 40) stopWith("No pieces found (game over, menu or ad?)")
            else Bot.status("Waiting for pieces...")
            delay(120)
            return
        }
        idle = 0

        val t0 = SystemClock.uptimeMillis()
        var plan = cache.get(snap.board, masks)
        val cached = plan != null
        if (plan == null) {
            plan = solver.solve(snap.board, masks)
            if (plan != null) cache.put(snap.board, masks, plan)
        }
        if (plan == null) { stopWith("No legal move - game over?"); return }
        Bot.status("Solved in ${SystemClock.uptimeMillis() - t0} ms${if (cached) " (cached)" else ""}")

        var board = snap.board
        for (m in plan.moves) {
            val tp = slots[m.piece] ?: return
            val shape = Shape.of(tp.mask)
            val tx = p.boardLeft + (m.col + shape.w / 2f) * p.cell + p.offX * p.cell + jitter(p.cell)
            val ty = p.boardTop + (m.row + shape.h / 2f) * p.cell + p.offY * p.cell + jitter(p.cell)
            val ok = svc.drag(
                tp.grabX, tp.grabY,
                tx.coerceIn(2f, screenW - 2f), ty.coerceIn(2f, screenH - 2f),
                p.dragMs.toLong()
            )
            if (!ok) { Bot.status("Gesture rejected - is the service enabled?"); delay(400); return }

            val before = board
            board = applyMove(board, shape, m)
            Stats.record(m.cleared)

            if (!p.tuned && m.cleared == 0) {
                // Self-calibration: measure where the block really landed and correct the finger offset.
                delay(p.gapMs.toLong() + 60)
                val after = readStable(false)?.board ?: return
                val added = after and before.inv()
                val lost = before and after.inv()
                val expected = shape.mask shl (m.row * 8 + m.col)
                if (lost == 0L && added == expected) {
                    if (++goodStreak >= 4) {
                        p.tuned = true
                        p.save(applicationContext)
                        Bot.status("Drag tuned (offset ${"%.2f".format(p.offX)}, ${"%.2f".format(p.offY)} cells)")
                    }
                    failedDrops = 0
                } else if (lost == 0L && added != 0L && added.countOneBits() == shape.cells) {
                    val r0 = java.lang.Long.numberOfTrailingZeros(added) / 8
                    var minC = 8
                    for (i in 0 until 64) if (((added ushr i) and 1L) != 0L) minC = minOf(minC, i % 8)
                    if (added == shape.mask shl (r0 * 8 + minC)) {
                        p.offY += (m.row - r0).toFloat()
                        p.offX += (m.col - minC).toFloat()
                        p.save(applicationContext)
                        goodStreak = 0
                        Bot.status("Adjusting drag offset to ${"%.1f".format(p.offX)}, ${"%.1f".format(p.offY)}")
                    }
                    return
                } else if (added == 0L) {
                    goodStreak = 0
                    if (++failedDrops >= 3) stopWith("Drops are not registering - raise drag ms or check the tray/board calibration")
                    return
                } else {
                    return
                }
            } else {
                delay(if (m.cleared > 0) p.clearWaitMs.toLong() else p.gapMs.toLong())
            }
        }

        // End-of-plan check: did the board end up exactly as predicted?
        val fin = readStable(false)?.board ?: return
        if (fin == plan.finalBoard) {
            mismatches = 0
        } else if (++mismatches >= 3) {
            mismatches = 0
            p.tuned = false
            goodStreak = 0
            Bot.status("Board drifted from prediction - re-tuning drag")
        }
    }

    private fun jitter(cell: Float): Float = (Random.nextFloat() - 0.5f) * cell * 0.10f

    private fun applyMove(board: Long, shape: Shape, m: Move): Long {
        var nb = board or (shape.mask shl (m.row * 8 + m.col))
        var clear = 0L
        for (i in 0 until 8) {
            if ((nb and Bits.ROW[i]) == Bits.ROW[i]) clear = clear or Bits.ROW[i]
            if ((nb and Bits.COL[i]) == Bits.COL[i]) clear = clear or Bits.COL[i]
        }
        nb = nb and clear.inv()
        return nb
    }
}
