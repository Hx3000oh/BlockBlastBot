package com.blastbot

import java.util.concurrent.ConcurrentHashMap

/**
 * 8x8 board packed in one Long: bit index = row * 8 + col.
 * Everything in the solver is plain 64-bit arithmetic, which is why it is fast.
 */
object Bits {
    val ROW = LongArray(8) { 0xFFL shl (it * 8) }
    val COL = LongArray(8) { 0x0101010101010101L shl it }
    val NOT0: Long = COL[0].inv()
    val NOT7: Long = COL[7].inv()
    const val LOW56 = 0x00FFFFFFFFFFFFFFL

    fun east(c: Long): Long = (c shl 1) and NOT0
    fun west(c: Long): Long = (c ushr 1) and NOT7

    /** Shift a shape so that its bounding box touches row 0 and column 0. */
    fun normalize(m: Long): Long {
        if (m == 0L) return 0L
        var x = m
        while ((x and ROW[0]) == 0L) x = x ushr 8
        while ((x and COL[0]) == 0L) x = x ushr 1
        return x
    }

    /** ASCII helper for the debug panel. */
    fun render(b: Long): String {
        val sb = StringBuilder()
        for (r in 0 until 8) {
            for (c in 0 until 8) sb.append(if (((b ushr (r * 8 + c)) and 1L) != 0L) '#' else '.')
            if (r < 7) sb.append('\n')
        }
        return sb.toString()
    }
}

/**
 * A piece shape anchored at the top-left of its bounding box, with every legal
 * board placement precomputed as a bitmask. Placement k -> row = k / cols, col = k % cols.
 */
class Shape private constructor(val mask: Long) {
    val h: Int
    val w: Int
    val cells: Int = mask.countOneBits()
    val cols: Int
    val placements: LongArray

    init {
        var hh = 0
        var ww = 0
        for (i in 0 until 64) {
            if (((mask ushr i) and 1L) != 0L) {
                hh = maxOf(hh, i / 8 + 1)
                ww = maxOf(ww, i % 8 + 1)
            }
        }
        h = hh
        w = ww
        cols = 9 - ww
        val list = ArrayList<Long>()
        for (r in 0..(8 - hh)) for (c in 0..(8 - ww)) list.add(mask shl (r * 8 + c))
        placements = list.toLongArray()
    }

    companion object {
        private val cache = ConcurrentHashMap<Long, Shape>()

        fun of(mask: Long): Shape = cache.getOrPut(mask) { Shape(mask) }

        /** "XX/X." style pattern -> Shape. */
        fun parse(pattern: String): Shape {
            var m = 0L
            var r = 0
            var c = 0
            for (ch in pattern) {
                when (ch) {
                    'X' -> { m = m or (1L shl (r * 8 + c)); c++ }
                    '.' -> c++
                    '/' -> { r++; c = 0 }
                }
            }
            return of(m)
        }
    }
}

/** Every shape the game is known to deal (used by the "can it still fit?" heuristic). Works offline, no downloads. */
object ShapeLib {
    private val patterns = listOf(
        "X", "XX", "XXX", "XXXX", "XXXXX",
        "X/X", "X/X/X", "X/X/X/X", "X/X/X/X/X",
        "XX/XX", "XXX/XXX/XXX", "XXX/XXX", "XX/XX/XX",
        "XX/X.", "XX/.X", "X./XX", ".X/XX",
        "XXX/X../X..", "XXX/..X/..X", "X../X../XXX", "..X/..X/XXX",
        "X./X./XX", ".X/.X/XX", "XX/X./X.", "XX/.X/.X", "XXX/X..", "XXX/..X", "X../XXX", "..X/XXX",
        "XXX/.X.", ".X./XXX", "X./XX/X.", ".X/XX/.X",
        ".XX/XX.", "XX./.XX", "X./XX/.X", ".X/XX/X."
    )
    val all: List<Shape> = patterns.map { Shape.parse(it) }
    val probes: List<Shape> = listOf("XXX/XXX/XXX", "XXXXX", "X/X/X/X/X", "XX/XX").map { Shape.parse(it) }
}
