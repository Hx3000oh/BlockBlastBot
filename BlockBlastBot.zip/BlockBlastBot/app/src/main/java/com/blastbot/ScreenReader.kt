package com.blastbot

import kotlin.math.abs
import kotlin.math.roundToInt

/** A copy of the latest screen pixels (RGBA_8888). Pixels are read straight from the buffer, no Bitmap needed. */
class Frame(
    val width: Int,
    val height: Int,
    val rowStride: Int,
    val pixelStride: Int,
    val data: ByteArray
) {
    fun rgb(x: Int, y: Int): Int {
        if (x < 0 || y < 0 || x >= width || y >= height) return 0
        val o = y * rowStride + x * pixelStride
        if (o + 2 >= data.size) return 0
        return ((data[o].toInt() and 0xFF) shl 16) or ((data[o + 1].toInt() and 0xFF) shl 8) or (data[o + 2].toInt() and 0xFF)
    }
}

object Px {
    fun red(c: Int) = (c shr 16) and 255
    fun green(c: Int) = (c shr 8) and 255
    fun blue(c: Int) = c and 255
    fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))
    fun lerp(a: Int, b: Int, t: Float): Int {
        val r = (red(a) + (red(b) - red(a)) * t).toInt()
        val g = (green(a) + (green(b) - green(a)) * t).toInt()
        val bl = (blue(a) + (blue(b) - blue(a)) * t).toInt()
        return (r shl 16) or (g shl 8) or bl
    }
}

class TrayPiece(val mask: Long, val grabX: Float, val grabY: Float)

class Snapshot(val board: Long, val pieces: List<TrayPiece?>) {
    fun sameAs(o: Snapshot): Boolean =
        board == o.board && pieces.size == o.pieces.size &&
            pieces.indices.all { (pieces[it]?.mask ?: 0L) == (o.pieces[it]?.mask ?: 0L) }
}

/**
 * Skin independence comes from never matching colours against a fixed palette:
 *  - board: each of the 64 cells is compared with ITS OWN learned "empty" colour (see [learn]).
 *  - tray: pieces are whatever differs from the tray background, whatever colour it is.
 * Geometry (where the board/tray are) is the same for every skin, so it is calibrated once.
 */
object Reader {

    private val SAMPLE = listOf(0f to 0f, 0.25f to 0f, -0.25f to 0f, 0f to 0.25f, 0f to -0.25f)

    private fun avg(f: Frame, cx: Float, cy: Float, d: Float): Int {
        var r = 0
        var g = 0
        var b = 0
        for (iy in -1..1) for (ix in -1..1) {
            val c = f.rgb((cx + ix * d).toInt(), (cy + iy * d).toInt())
            r += Px.red(c); g += Px.green(c); b += Px.blue(c)
        }
        return ((r / 9) shl 16) or ((g / 9) shl 8) or (b / 9)
    }

    fun cellColors(f: Frame, p: Profile): IntArray {
        val out = IntArray(64)
        for (r in 0 until 8) for (c in 0 until 8) {
            out[r * 8 + c] = avg(f, p.boardLeft + (c + 0.5f) * p.cell, p.boardTop + (r + 0.5f) * p.cell, p.cell * 0.14f)
        }
        return out
    }

    private fun median(cols: List<Int>): Int {
        val rs = cols.map { Px.red(it) }.sorted()
        val gs = cols.map { Px.green(it) }.sorted()
        val bs = cols.map { Px.blue(it) }.sorted()
        val m = cols.size / 2
        return (rs[m] shl 16) or (gs[m] shl 8) or bs[m]
    }

    /**
     * Learn the current skin's "empty cell" colours. Works from any board that is at least ~40% empty
     * (a fresh game is ideal). Two colours are learned (checkerboard parity) and then kept per cell.
     */
    fun learn(f: Frame, p: Profile): Boolean {
        val col = cellColors(f, p)
        val med = IntArray(2) { par -> median((0 until 64).filter { (it / 8 + it % 8) % 2 == par }.map { col[it] }) }
        var filled = 0
        for (i in 0 until 64) {
            val m = med[(i / 8 + i % 8) % 2]
            if (Px.dist(col[i], m) < p.threshold) p.ref[i] = col[i] else { p.ref[i] = m; filled++ }
        }
        if (filled > 40) return false
        p.learned = true
        return true
    }

    fun readBoard(f: Frame, p: Profile): Long {
        val col = cellColors(f, p)
        var b = 0L
        for (i in 0 until 64) if (Px.dist(col[i], p.ref[i]) > p.threshold) b = b or (1L shl i)
        return b
    }

    private class Box(val x0: Int, val x1: Int, val y0: Int, val y1: Int)

    /** Finds the (up to) three pieces in the tray band and turns each into a bitmask shape. */
    fun readTray(f: Frame, p: Profile): List<TrayPiece?> {
        val none = listOf<TrayPiece?>(null, null, null)
        val st = 2
        val l = p.trayLeft.toInt()
        val r = p.trayRight.toInt()
        val t = p.trayTop.toInt()
        val b = p.trayBottom.toInt()
        val gw = (r - l) / st
        val gh = (b - t) / st
        if (gw < 30 || gh < 10) return none

        // Foreground mask = pixels that differ from the tray background (edge-to-edge gradient per row).
        val mask = Array(gh) { BooleanArray(gw) }
        for (gy in 0 until gh) {
            val y = t + gy * st
            val left = f.rgb(l + 4, y)
            val right = f.rgb(r - 4, y)
            for (gx in 0 until gw) {
                val bg = Px.lerp(left, right, gx / gw.toFloat())
                mask[gy][gx] = Px.dist(f.rgb(l + gx * st, y), bg) > p.pieceTol
            }
        }

        // Bounding box per slot (tray is split into three equal columns).
        val slotW = gw / 3
        val boxes = arrayOfNulls<Box>(3)
        for (s in 0 until 3) {
            val xs = s * slotW
            val xe = if (s == 2) gw else xs + slotW
            val colHits = IntArray(xe - xs)
            val rowHits = IntArray(gh)
            for (gy in 0 until gh) for (gx in xs until xe) if (mask[gy][gx]) { colHits[gx - xs]++; rowHits[gy]++ }
            val cx = colHits.indices.filter { colHits[it] >= 2 }
            val ry = rowHits.indices.filter { rowHits[it] >= 2 }
            if (cx.isEmpty() || ry.isEmpty()) continue
            boxes[s] = Box(xs + cx.first(), xs + cx.last(), ry.first(), ry.last())
        }
        val present = boxes.filterNotNull()
        if (present.isEmpty()) return none

        // Tray cell size relative to board cell size: auto-estimated once, then reused.
        var ratio = p.trayScale
        if (ratio <= 0f) {
            var bestErr = Float.MAX_VALUE
            var bestRatio = 0.6f
            var rho = 0.40f
            while (rho <= 0.90f) {
                val s = rho * p.cell / st
                var err = abs(rho - 0.6f) * 0.3f
                for (bx in present) {
                    val wv = (bx.x1 - bx.x0 + 1) / s
                    val hv = (bx.y1 - bx.y0 + 1) / s
                    for (v in floatArrayOf(wv, hv)) {
                        val n = v.roundToInt()
                        err += if (n in 1..5) abs(v - n) else 10f
                    }
                }
                if (err < bestErr) { bestErr = err; bestRatio = rho }
                rho += 0.005f
            }
            ratio = bestRatio
            if (present.size >= 2 && bestErr / (2 * present.size) < 0.12f) p.trayScale = ratio
        }
        val sGrid = ratio * p.cell / st

        val out = ArrayList<TrayPiece?>()
        for (s in 0 until 3) {
            val bx = boxes[s]
            if (bx == null) { out.add(null); continue }
            val wg = (bx.x1 - bx.x0 + 1).toFloat()
            val hg = (bx.y1 - bx.y0 + 1).toFloat()
            val wc = (wg / sGrid).roundToInt().coerceIn(1, 8)
            val hc = (hg / sGrid).roundToInt().coerceIn(1, 8)
            val cw = wg / wc
            val ch = hg / hc
            val mx = bx.x0 + wg / 2
            val my = bx.y0 + hg / 2
            var bits = 0L
            var bestD = Float.MAX_VALUE
            var gx0 = 0f
            var gy0 = 0f
            for (i in 0 until hc) for (j in 0 until wc) {
                val cx = bx.x0 + (j + 0.5f) * cw
                val cy = bx.y0 + (i + 0.5f) * ch
                var hits = 0
                for ((ox, oy) in SAMPLE) {
                    val gx = (cx + ox * cw).toInt()
                    val gy = (cy + oy * ch).toInt()
                    if (gy in 0 until gh && gx in 0 until gw && mask[gy][gx]) hits++
                }
                if (hits >= 3) {
                    bits = bits or (1L shl (i * 8 + j))
                    val d = (cx - mx) * (cx - mx) + (cy - my) * (cy - my)
                    if (d < bestD) { bestD = d; gx0 = cx; gy0 = cy }
                }
            }
            bits = Bits.normalize(bits)
            if (bits == 0L) { out.add(null); continue }
            // grab the filled cell closest to the piece centre: touching a real block is always safe
            out.add(TrayPiece(bits, l + gx0 * st, t + gy0 * st))
        }
        return out
    }
}
