package com.blastbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.random.Random

/**
 * Two jobs: (1) inject drag gestures, (2) host the small floating control panel.
 * It does not read window content; onAccessibilityEvent is intentionally empty.
 */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var calView: View? = null
    private lateinit var statusTv: TextView
    private lateinit var debugTv: TextView
    private lateinit var startBtn: Button
    private val hideDebug = Runnable { debugTv.visibility = View.GONE }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Bot.ensure(applicationContext)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildPanel()
        Bot.statusListener = { s -> ui.post { statusTv.text = s; startBtn.text = if (Bot.running) "Stop" else "Start" } }
        Bot.debugListener = { s -> ui.post { debugTv.text = s; debugTv.visibility = View.VISIBLE; ui.removeCallbacks(hideDebug); ui.postDelayed(hideDebug, 6000) } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        Bot.statusListener = null
        Bot.debugListener = null
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { calView?.let { wm.removeView(it) } } catch (e: Exception) { }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- gesture

    /** Human-looking drag: slightly curved path, slightly randomised duration. Returns false if the system rejected it. */
    suspend fun drag(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val bend = (Random.nextFloat() - 0.5f) * 0.10f
        val path = Path().apply {
            moveTo(x1, y1)
            quadTo((x1 + x2) / 2 - dy * bend, (y1 + y2) / 2 + dx * bend, x2, y2)
        }
        val dur = (ms * (0.85 + Random.nextDouble() * 0.35)).toLong().coerceAtLeast(40L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, dur))
            .build()
        return suspendCancellableCoroutine { cont ->
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!accepted && cont.isActive) cont.resume(false)
        }
    }

    // ---------------------------------------------------------------- floating panel

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xB0000000.toInt())
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        statusTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 10f; text = "Idle"; maxWidth = dp(150) }
        debugTv = TextView(this).apply {
            setTextColor(Color.GREEN); textSize = 9f; typeface = Typeface.MONOSPACE; visibility = View.GONE
        }
        startBtn = smallButton("Start") {
            Bot.running = !Bot.running
            Bot.status(if (Bot.running) "Running" else "Stopped")
        }
        root.addView(statusTv)
        root.addView(startBtn)
        root.addView(smallButton("1 Calibrate") { startCalibration() })
        root.addView(smallButton("2 Learn skin") { Bot.pending = Cmd.LEARN })
        root.addView(smallButton("Test read") { Bot.pending = Cmd.TEST })
        root.addView(debugTv)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 0; y = dp(24) }
        wm.addView(root, lp)
        panel = root
    }

    // ---------------------------------------------------------------- calibration (4 taps)

    private fun startCalibration() {
        Bot.running = false
        if (calView != null) return
        val steps = listOf(
            "1/4  Tap the TOP-LEFT corner of the 8x8 board",
            "2/4  Tap the BOTTOM-RIGHT corner of the 8x8 board",
            "3/4  Tap the TOP-LEFT of the area holding the 3 pieces",
            "4/4  Tap the BOTTOM-RIGHT of the area holding the 3 pieces"
        )
        val v = CalView(this, steps) { pts -> finishCalibration(pts) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        calView = v
    }

    private fun finishCalibration(pts: List<PointF>) {
        calView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        calView = null
        val p = Bot.profile
        val x0 = minOf(pts[0].x, pts[1].x)
        val x1 = maxOf(pts[0].x, pts[1].x)
        val y0 = minOf(pts[0].y, pts[1].y)
        val y1 = maxOf(pts[0].y, pts[1].y)
        p.boardLeft = x0
        p.boardTop = y0
        p.cell = ((x1 - x0) + (y1 - y0)) / 16f
        p.trayLeft = minOf(pts[2].x, pts[3].x)
        p.trayRight = maxOf(pts[2].x, pts[3].x)
        p.trayTop = minOf(pts[2].y, pts[3].y)
        p.trayBottom = maxOf(pts[2].y, pts[3].y)
        p.trayScale = 0f
        p.tuned = false
        p.offX = 0f
        p.offY = 0f
        p.save(applicationContext)
        Bot.status("Calibrated (cell ${p.cell.toInt()} px). Start a fresh game, then press 2 Learn skin.")
    }

    /** Transparent full-screen layer that records four taps and previews the resulting grid. */
    private class CalView(ctx: Context, val steps: List<String>, val done: (List<PointF>) -> Unit) : View(ctx) {
        private val pts = ArrayList<PointF>()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val loc = IntArray(2)

        init { setBackgroundColor(0x40000000) }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP && pts.size < 4) {
                pts.add(PointF(e.rawX, e.rawY))
                invalidate()
                if (pts.size == 4) postDelayed({ done(ArrayList(pts)) }, 2000)
            }
            return true
        }

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            val ox = loc[0].toFloat()
            val oy = loc[1].toFloat()
            paint.textSize = 40f
            paint.color = Color.YELLOW
            paint.style = Paint.Style.FILL
            c.drawText(if (pts.size < 4) steps[pts.size] else "Preview - accepted in 2 s (press 1 Calibrate to redo)", 24f, 120f - oy, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.CYAN
            if (pts.size >= 2) {
                val x0 = minOf(pts[0].x, pts[1].x) - ox
                val x1 = maxOf(pts[0].x, pts[1].x) - ox
                val y0 = minOf(pts[0].y, pts[1].y) - oy
                val y1 = maxOf(pts[0].y, pts[1].y) - oy
                for (i in 0..8) {
                    val x = x0 + (x1 - x0) * i / 8f
                    val y = y0 + (y1 - y0) * i / 8f
                    c.drawLine(x, y0, x, y1, paint)
                    c.drawLine(x0, y, x1, y, paint)
                }
            }
            if (pts.size == 4) {
                paint.color = Color.MAGENTA
                val l = minOf(pts[2].x, pts[3].x) - ox
                val r = maxOf(pts[2].x, pts[3].x) - ox
                val t = minOf(pts[2].y, pts[3].y) - oy
                val b = maxOf(pts[2].y, pts[3].y) - oy
                c.drawRect(l, t, r, b, paint)
                for (i in 1..2) c.drawLine(l + (r - l) * i / 3f, t, l + (r - l) * i / 3f, b, paint)
            }
            paint.style = Paint.Style.FILL
            paint.color = Color.RED
            for (p in pts) c.drawCircle(p.x - ox, p.y - oy, 10f, paint)
        }
    }
}
