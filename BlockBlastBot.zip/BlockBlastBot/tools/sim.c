// Bitboard beam-search solver simulation for Block Blast (mirrors Solver.kt)
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
typedef uint64_t u64;
#define POP __builtin_popcountll

static u64 ROW[8], COL[8], NOT0, NOT7;
typedef struct { u64 mask; int h, w, n; u64 pm[64]; } Shape;
static Shape shapes[64];
static int nshapes = 0;

// tunables
static int BEAM = 16;
static double W_DEAD = 3.0;
static double W_FILLED = 2.0, W_TRANS = 0.8, W_R1 = 14, W_R2 = 7, W_R3 = 2, W_FLEX = 0.6, W_COMBO = 6;
static double LB[10] = {0, 10, 30, 60, 100, 150, 210, 280, 360, 450};

static void add_shape(const char *s) {
    Shape *sh = &shapes[nshapes++];
    int r = 0, c = 0, h = 1, w = 0, cw = 0;
    sh->mask = 0;
    for (const char *p = s;; p++) {
        if (*p == 'X') { sh->mask |= 1ULL << (r * 8 + c); c++; cw = c; if (cw > w) w = cw; }
        else if (*p == '.') c++;
        else if (*p == '/') { r++; c = 0; h++; }
        else break;
    }
    sh->h = h; sh->w = w; sh->n = 0;
    for (int rr = 0; rr + h <= 8; rr++)
        for (int cc = 0; cc + w <= 8; cc++)
            sh->pm[sh->n++] = sh->mask << (rr * 8 + cc);
}
// placement index -> (r,c)
static inline void pos_of(const Shape *sh, int idx, int *r, int *c) {
    int cols = 8 - sh->w + 1;
    *r = idx / cols; *c = idx % cols;
}

static void init(void) {
    for (int i = 0; i < 8; i++) { ROW[i] = 0xFFULL << (8 * i); COL[i] = 0x0101010101010101ULL << i; }
    NOT0 = ~COL[0]; NOT7 = ~COL[7];
    const char *L[] = {"X", "XX", "XXX", "XXXX", "XXXXX", "X/X", "X/X/X", "X/X/X/X", "X/X/X/X/X",
        "XX/XX", "XXX/XXX/XXX", "XXX/XXX", "XX/XX/XX",
        "XX/X.", "XX/.X", "X./XX", ".X/XX",
        "XXX/X../X..", "XXX/..X/..X", "X../X../XXX", "..X/..X/XXX",
        "X./X./XX", ".X/.X/XX", "XX/X./X.", "XX/.X/.X", "XXX/X..", "XXX/..X", "X../XXX", "..X/XXX",
        "XXX/.X.", ".X./XXX", "X./XX/X.", ".X/XX/.X",
        ".XX/XX.", "XX./.XX", "X./XX/.X", ".X/XX/X."};
    for (unsigned i = 0; i < sizeof(L) / sizeof(L[0]); i++) add_shape(L[i]);
}

static inline u64 east(u64 c) { return (c << 1) & NOT0; }
static inline u64 west(u64 c) { return (c >> 1) & NOT7; }

static int clear_lines(u64 *b) {
    u64 m = 0; int n = 0;
    for (int i = 0; i < 8; i++) {
        if ((*b & ROW[i]) == ROW[i]) { m |= ROW[i]; n++; }
        if ((*b & COL[i]) == COL[i]) { m |= COL[i]; n++; }
    }
    *b &= ~m;
    return n;
}

static int probe_ids[4]; // 3x3, 1x5, 5x1, 2x2

static double eval_board(u64 b) {
    double s = -W_FILLED * POP(b);
    u64 hx = (b ^ (b >> 1)) & NOT7;
    u64 vx = (b ^ (b >> 8)) & 0x00FFFFFFFFFFFFFFULL;
    s -= W_TRANS * (POP(hx) + POP(vx));
    u64 empty = ~b;
    while (empty) {
        u64 comp = empty & (~empty + 1);
        for (;;) {
            u64 g = (comp | east(comp) | west(comp) | (comp << 8) | (comp >> 8)) & empty;
            if (g == comp) break;
            comp = g;
        }
        int sz = POP(comp);
        if (sz == 1) s -= W_R1; else if (sz == 2) s -= W_R2; else if (sz == 3) s -= W_R3;
        empty &= ~comp;
    }
    if (W_DEAD > 0) {
        for (int k = 0; k < nshapes; k++) {
            const Shape *sh = &shapes[k];
            int ok = 0;
            for (int i = 0; i < sh->n; i++) if ((b & sh->pm[i]) == 0) { ok = 1; break; }
            if (!ok) s -= W_DEAD * (sh->n ? 1 : 0) * POP(sh->mask);
        }
    }
    for (int k = 0; k < 4; k++) {
        const Shape *sh = &shapes[probe_ids[k]];
        int cnt = 0;
        for (int i = 0; i < sh->n && cnt < 6; i++) if ((b & sh->pm[i]) == 0) cnt++;
        s += W_FLEX * cnt;
    }
    return s;
}

typedef struct { u64 board; double gain, score; int streak, depth; signed char pi[3], pr[3], pc[3], pcl[3]; } Node;

static int cmp_node(const void *a, const void *b) {
    double x = ((const Node *)a)->score, y = ((const Node *)b)->score;
    return (x < y) - (x > y);
}

static Node pool[2][8192];

static int beam(u64 board, const int *order, int m, const int *shape_of, Node *best) {
    int cur = 0, ncur = 1;
    memset(&pool[0][0], 0, sizeof(Node));
    pool[0][0].board = board;
    int found = 0;
    for (int d = 0; d < m; d++) {
        int nn = 0;
        Node *cand = pool[1 - cur];
        const Shape *sh = &shapes[shape_of[order[d]]];
        for (int i = 0; i < ncur; i++) {
            Node *nd = &pool[cur][i];
            int any = 0;
            for (int k = 0; k < sh->n; k++) {
                if (nd->board & sh->pm[k]) continue;
                any = 1;
                Node c = *nd;
                u64 nb = nd->board | sh->pm[k];
                int ln = clear_lines(&nb);
                c.board = nb;
                c.gain = nd->gain;
                if (ln > 0) { c.gain += LB[ln > 9 ? 9 : ln] + W_COMBO * nd->streak; c.streak = nd->streak + 1; }
                else c.streak = 0;
                int r, cc; pos_of(sh, k, &r, &cc);
                c.pi[d] = order[d]; c.pr[d] = r; c.pc[d] = cc; c.pcl[d] = ln;
                c.depth = d + 1;
                c.score = c.gain + eval_board(nb);
                if (nn < 8192) cand[nn++] = c;
            }
            if (!any) { // terminal partial
                double sc = nd->gain + eval_board(nd->board);
                if (!found || (nd->depth > best->depth) || (nd->depth == best->depth && sc > best->score)) {
                    *best = *nd; best->score = sc; found = 1;
                }
            }
        }
        if (nn == 0) return found;
        qsort(cand, nn, sizeof(Node), cmp_node);
        ncur = nn < BEAM ? nn : BEAM;
        cur = 1 - cur;
    }
    for (int i = 0; i < ncur; i++) {
        Node *nd = &pool[cur][i];
        if (!found || nd->depth > best->depth || (nd->depth == best->depth && nd->score > best->score)) { *best = *nd; found = 1; }
    }
    return found;
}

static int solve(u64 board, const int *shape_of, int n, Node *best) {
    int perm3[6][3] = {{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
    int perm2[2][2] = {{0,1},{1,0}};
    int perm1[1][1] = {{0}};
    int np = n == 3 ? 6 : n == 2 ? 2 : 1;
    int have = 0;
    Node b; memset(&b, 0, sizeof b);
    for (int p = 0; p < np; p++) {
        const int *o = n == 3 ? perm3[p] : n == 2 ? perm2[p] : perm1[p];
        Node cand; memset(&cand, 0, sizeof cand);
        if (beam(board, o, n, shape_of, &cand)) {
            if (!have || cand.depth > b.depth || (cand.depth == b.depth && cand.score > b.score)) { b = cand; have = 1; }
        }
    }
    if (have) *best = b;
    return have;
}

int main(int argc, char **argv) {
    init();
    // probe shapes: 3x3 idx10, 1x5 idx4, 5x1 idx8, 2x2 idx9
    probe_ids[0] = 10; probe_ids[1] = 4; probe_ids[2] = 8; probe_ids[3] = 9;
    int games = argc > 1 ? atoi(argv[1]) : 50;
    int cap = argc > 2 ? atoi(argv[2]) : 3000;
    if (argc > 3) BEAM = atoi(argv[3]);
    if (argc > 4) W_FILLED = atof(argv[4]);
    if (argc > 5) W_TRANS = atof(argv[5]);
    if (argc > 6) W_R1 = atof(argv[6]);
    if (argc > 7) W_FLEX = atof(argv[7]);
    if (argc > 8) W_COMBO = atof(argv[8]);
    if (argc > 9) W_DEAD = atof(argv[9]);
    srand(12345);
    long total = 0; int capped = 0, minp = 1 << 30; long lines_total = 0;
    int *res = malloc(sizeof(int) * games);
    for (int g = 0; g < games; g++) {
        u64 board = 0; int placed = 0;
        while (placed < cap) {
            int sh[3] = {rand() % nshapes, rand() % nshapes, rand() % nshapes};
            Node best;
            if (!solve(board, sh, 3, &best) || best.depth == 0) break;
            for (int d = 0; d < best.depth; d++) lines_total += best.pcl[d];
            board = best.board; placed += best.depth;
            if (best.depth < 3) break;
        }
        res[g] = placed; total += placed; if (placed >= cap) capped++; if (placed < minp) minp = placed;
    }
    // median
    for (int i = 0; i < games; i++) for (int j = i + 1; j < games; j++) if (res[j] < res[i]) { int t = res[i]; res[i] = res[j]; res[j] = t; }
    printf("games=%d cap=%d beam=%d avg_pieces=%.0f median=%d min=%d capped=%d/%d lines/game=%.0f\n",
           games, cap, BEAM, (double)total / games, res[games / 2], minp, capped, games, (double)lines_total / games);
    return 0;
}
